# Otto

## Optimal Translation Trainer Operative

Otto is a program that uses my personal French/German Excel lexicon to train the user on learning vocabulary.

I was inspired by the Anki app in which we create decks of cards with a face to read and the other to guess. The principle is to self-evaluate the difficulty to guess the corresponding information by adding a rate for each one after seeing the result. Here we add a weight to the word in order to adjust its probability to appear in the training session.

**Warnings**:

- I started this lexicon when I took my first German lesson and it is still ongoing. Thus it may have some errors for which I apologize.

- This program is conceived to work on my specific Excel file's layout. However new words can be added !

**PS:** The program is still under development. I intend to make it more efficient, cleaner and add an english column.